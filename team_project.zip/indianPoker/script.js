// class IndianPoker {
//     constructor() {}
// }

// class Player {
//     constructor(num, shape) {
//         this.shape = shape;
//         this.num = num;
//     }
// }

// const game = new IndianPoker();
